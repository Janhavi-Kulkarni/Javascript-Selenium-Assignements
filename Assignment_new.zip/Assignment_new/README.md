# Portals-tests

UI tests for shadowbox portals.

To run the tests you need:
- install nodeJS
- install selenium-webdriver (Drives a browser natively)
- install chrome-driver
- install mocha (Test framework)
- install chai (Assertion library)
- install mochawesome (UI reporting)

Structure of programm:
- /portal/base_page.js - basic work with selenium-webdriver;
- /portal/main_page.js - work with the portal page;
- /test/...test.js - tests themselves;
