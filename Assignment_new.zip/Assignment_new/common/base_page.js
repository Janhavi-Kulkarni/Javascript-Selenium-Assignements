let webdriver = require("selenium-webdriver");
let By = webdriver.By,
  until = webdriver.until;

class Page {
  constructor() {
    this.driver = null;
  }

  async init() {
    this.driver = new webdriver.Builder().forBrowser("chrome").build();
    this.driver
      .manage()
      .window()
      .maximize();
    // await driver.manage().window().setPosition(0, 0);
  }
  async execute() {
    this.driver = new webdriver.executeScript()
    this.driver
      .manage()
      .window()
      .maximize();
    // await driver.manage().window().setPosition(0, 0);
  }

  async navigateToUrl(url){
      return await this.driver.get(url);
  }

  async waitForPageLoad(){
    return this.driver.executeScript('return document.readyState').then(function(readyState) {
        return readyState === 'complete';
  })
}

async find_element(locator) {
    let locatedElement;
    try {
      
      await this.driver.wait(until.elementLocated(locator), 15000);
      locatedElement = this.driver.findElement(locator);
      return locatedElement;
    }
    catch (e) {
      if (e instanceof webdriver.error.StaleElementReferenceError) {
        try{
          await this.wait(2000);
          locatedElement = this.driver.findElement(locator);
         return locatedElement;
          }
          catch(e){
          console.log(`Stale Exception ${e}`);
          throw Error(e);
          }
      }
      else if (e instanceof webdriver.error.NoSuchElementError) {
        console.log(`No such element is found ${e}`);
        throw Error(e);
      }
      else if (e instanceof webdriver.error.TimeoutError) {
        console.log(`No such element is found ${e}`);
        throw Error(e);
      }
      else {
        console.log(e);
        throw Error(e);
      }

    }
  }

  async find_elements(locator) {
    let locatedElement;
    try {
      
      await this.driver.wait(until.elementLocated(locator), 15000);
      locatedElement = this.driver.findElements(locator);
      return locatedElement;
    }
    catch (e) {
      if (e instanceof webdriver.error.StaleElementReferenceError) {
        try{
          await this.wait(2000);
          locatedElement = this.driver.findElements(locator);
         return locatedElement;
          }
          catch(e){
          console.log(`Stale Exception ${e}`);
          throw Error(e);
          }
      }
      else if (e instanceof webdriver.error.NoSuchElementError) {
        console.log(`No such element is found ${e}`);
        throw Error(e);
      }
      else if (e instanceof webdriver.error.TimeoutError) {
        console.log(`No such element is found ${e}`);
        throw Error(e);
      }
      else {
        console.log(e);
        throw Error(e);
      }

    }
  }

  async read(locator){
      let element=await this.find_element(locator);
      return element.getText();
  }

  async getcssValue(locator){
    let element=await this.find_element(locator);
    return element.getCssValue
  }

  async write(locator,text){
      let element=await this.find_element(locator);
      return element.sendKeys(text);
  }

  async clickElement(locator){
      await this.WaitForElementVisible(locator);
      let element=await this.find_element(locator);
      return element.click();
  }

  async close(){
      return await this.driver.close();
  }

  async quit(){
      return await this.driver.quit();
  }

  async WaitForElementVisible(locator) {
    let element = await this.find_element(locator);
    await this.driver.wait(until.elementIsVisible(element), 2000);

  }

  async clearText(locator) {
    let element = await this.find_element(locator);
    return element.clear();
  }

  async validateEnabled(locator){
    let element = await this.find_element(locator);
    return element.isEnabled()
  }

  async validateVisible(locator){
    let element=await this.find_element(locator);
    return element.isDisplayed();
  }
  async wait(ms) {
    return this.driver.sleep(ms);
  }


}

module.exports = Page;
