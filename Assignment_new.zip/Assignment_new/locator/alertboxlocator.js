let webdriver = require("selenium-webdriver");
let By = webdriver.By;

module.exports={
    btn_alertbox:By.css(".panel-primary:nth-child(4) button.btn.btn-default:nth-child(4)"),
    btn_confirmationbox:By.css(".panel-primary:nth-child(5) button.btn.btn-default.btn-lg:nth-child(4)"),
    btn_promtbox:By.css(".panel-primary:nth-child(6) button.btn.btn-default.btn-lg:nth-child(4)"),
    output_confirmbox:By.id("confirm-demo"),
    output_prompt:By.id("prompt-demo")
};