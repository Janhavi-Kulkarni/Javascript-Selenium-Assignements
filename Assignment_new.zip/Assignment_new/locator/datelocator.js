let webdriver = require("selenium-webdriver");
let By = webdriver.By;

module.exports={

    // side menu
    menu_datepicker:By.linkText("Date pickers"),
    menu_bootstrap_datepicker:By.linkText("Bootstrap Date Picker"),

    //date picker
    date_picker:By.xpath("//i[@class='glyphicon glyphicon-th']"),
    btn_today:By.className("today"),
    btn_clear:By.className("clear"),
    textbox_date:By.xpath("//input[@placeholder='dd/mm/yyyy']"),
    btn_prev:By.className("prev"),
    btn_next:By.className("next"),
    datepicker_month:By.className("datepicker-switch"),
    panel_heading:By.className("panel-heading"),
    

    select_date:function(date){
        let selected_date=By.xpath(`//td[contains(text(),'${date}')]`);
        return selected_date;

    },

    select_month(month){
        let selected_month=By.xpath(`//th[contains(text(),'${month}')]`);
        return selected_month;
    }
}