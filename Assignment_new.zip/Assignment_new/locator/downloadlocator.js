let webdriver = require("selenium-webdriver");
let By = webdriver.By;

module.exports={
    btn_download:By.id("cricle-btn"),
    progress_circle:By.className("percenttext")
}