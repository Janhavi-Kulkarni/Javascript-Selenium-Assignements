let webdriver = require("selenium-webdriver");
let By = webdriver.By;

module.exports={
    dragable_component_box:By.id("todrag"),
    // dropzone:By.id("mydropzone"),
    // dropzone:By.xpath("//div[@id='mydropzone']"),
    dropzone:By.css("#mydropzone"),
    droped_item_list:By.xpath("//div[id='droppedlist']"),
    // dragable_component:By.xpath("//span[contains(text(),'Draggable 1')]"),

    dragable_components:function(component_name){
        let component=By.xpath(`//span[contains(text(),'${component_name}')]`);
        return component;
    }


}