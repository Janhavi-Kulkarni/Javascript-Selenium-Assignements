let webdriver = require("selenium-webdriver");
let By = webdriver.By;

module.exports={
    list_items:By.className("list-group-item"),

    list_option:function(item){
        xpath=`//li[contains(text(),'${item}')]`;
        let ele=By.xpath(xpath);
        // console.log(ele);
        return ele;
    },
    btn_moveright:By.className("btn btn-default btn-sm move-right"),
    btn_moveleft:By.className("btn btn-default btn-sm move-left"),
    select_all_left:By.xpath("//div[@class='well text-right']//i[@class='glyphicon glyphicon-unchecked']"),
    select_all_right:By.xpath("//div[@class='well']//i[@class='glyphicon glyphicon-unchecked']"),
    search_target:By.css(".list-right.col-md-5:nth-child(6)  input.form-control"),
    
}