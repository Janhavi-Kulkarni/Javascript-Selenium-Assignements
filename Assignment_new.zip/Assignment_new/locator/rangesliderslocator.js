let webdriver = require("selenium-webdriver");
let By = webdriver.By;

module.exports={
    // rng_slider_one:By.xpath("//div[@class='range']//input[@name='range']"),
    rng_slider_one:By.css(".row.sliders:nth-child(2) div.col-md-6:nth-child(1) div.range:nth-child(2) > input:nth-child(1)"),
    rng_slider_two:By.css(".row.sliders:nth-child(2) div.col-md-6:nth-child(2) div.range:nth-child(2) > input:nth-child(1)"),
    rng_slider_three:By.css(".row.sliders:nth-child(3) div.col-md-6:nth-child(1) div.range.range-success:nth-child(2) > input:nth-child(1)"),
    
    rng_slider_four:By.css(".row.sliders:nth-child(3) div.col-md-6:nth-child(2) div.range.range-info:nth-child(2) > input:nth-child(1)"),
    rng_slider_five:By.css(".row.sliders:nth-child(4) div.col-md-6:nth-child(1) div.range.range-warning:nth-child(2) > input:nth-child(1)"),
    rng_slider_six:By.css(".row.sliders:nth-child(4) div.col-md-6:nth-child(2) div.range.range-danger:nth-child(2) > input:nth-child(1)"),

}