let webdriver = require("selenium-webdriver");
let By = webdriver.By;

module.exports={
    tsk_txt_filter:By.id("task-table-filter"),
    tsk_search_result_assignee:By.css("table.table-hover  tr:nth-child(1) > td:nth-child(3)"),
    tsk_search_result_status:By.css("table.table-hover  tr:nth-child(1) > td:nth-child(4)"),
    tsk_table_rows:By.css("#task-table > tbody>tr"),
    usr_btn_filter:By.className("btn btn-default btn-xs btn-filter"),
    usr_txt_username:By.xpath("//input[@placeholder='Username']"),
    usr_search_result_usrname:By.css(".filterable:nth-child(2) tr:nth-child(3) > td:nth-child(2)"),

    tsk_filtered_data:function(value){
        let xpath=By.xpath(`//td[contains(text(),'${value}')]`);
        return xpath;
    }
}