let Page = require("../common/base_page");
let alertlocator = require("../locator/alertboxlocator.js");
const { Builder, By, Key, until, WebElement } = require('selenium-webdriver');
let assert = require("chai").assert;

class AlertBox extends Page{

    constructor(driver) {
        super();
        this.driver = driver;
    }
    async acceptAlert(){
        await this.driver.wait(until.alertIsPresent());
        await this.driver
          .switchTo()
          .alert()
          .accept();
        // await this.wait(1000);
    }

    async rejectAlert(){
        await this.driver.wait(until.alertIsPresent());
        await this.driver
          .switchTo()
          .alert()
          .dismiss()
        // await this.wait(1000);
    }

    async validateAlert(){
        await this.clickElement(alertlocator.btn_alertbox);
        await this.acceptAlert();
    }

    async acceptConfirmtion(){
        await this.clickElement(alertlocator.btn_confirmationbox);
        await this.acceptAlert();
    }
    async cancelConfirmtion(){
        await this.clickElement(alertlocator.btn_confirmationbox);
        await this.rejectAlert();
    }

    async validateConfirmationResult(){
        let result=await this.read(alertlocator.output_confirmbox);
        return result;
    }

    async prompt_settext(text){
        await this.driver.wait(until.alertIsPresent());
        await this.driver
          .switchTo()
          .alert()
          .sendKeys(text);
    }

    async validatePromptResult(){
        let result=await this.read(alertlocator.output_prompt);
        return result;
    }

    async promptAccept(text){
        await this.clickElement(alertlocator.btn_promtbox);
        await this.prompt_settext(text);
        await this.acceptAlert();
    }

}
module.exports=AlertBox;