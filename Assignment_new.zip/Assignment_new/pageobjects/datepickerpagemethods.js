let Page = require("../common/base_page");
let datelocator = require("../locator/datelocator.js");
const { Builder, By, Key, until, WebElement } = require('selenium-webdriver');
let assert = require("chai").assert;

class Datepicker extends Page {
    constructor(driver) {
        super();
        this.driver = driver;

    }
    async navigateToDatepickerMenu() {
        let ele = this.find_element(datelocator);
        console.log(ele);

    }

    async validateFutureDate(date) {
        let day = new Date();
        let current_date = day.getDate();
        
        if (date > current_date) {
            let attr=await this.find_element(datelocator.select_date(date));
            let status=await attr.getAttribute("class");
            if(status=="disabled day")
            {
                return true;
            }
            else{
                return false;
            }
            
        }

    }

    async selectMonth(month){
        let day = new Date();
        let current_month=day.getMonth();
        let selected_month=await this.read(datelocator.datepicker_month);
        console.log("smonth="+selected_month);
        
        while(await this.read(datelocator.datepicker_month)!=`${month}`){
            if(await this.validateVisible(datelocator.btn_next)){
                await this.clickElement(datelocator.btn_next);
            }
            else{
                await this.clickElement(datelocator.btn_prev);
            }
           
        }

    }

    async click_on_datepicker(){
        await this.clickElement(datelocator.date_picker);
    }

    async get_current_date(){
        let day = new Date();
        let current_date = day.getDate();
        let current_month=day.getMonth();
        let current_year=day.getUTCFullYear();
        let today=`${current_date}/${current_month}/${current_year}`;
        return today;
            }

    async selectDate_today(){
        await this.clickElement(datelocator.btn_today);

    }

    async selectDate_any(month,date){
        while(true){
            let calenderMonth=this.read(datelocator.datepicker_month);
            if(calenderMonth==month){
                break;
            }
            else{
                await this.clickElement(datelocator.btn_prev);
            
                }
                break;
        }
        await this.clickElement(datelocator.select_date(date));
    }
    async selectDate_write(date){
        // let current_date=await this.get_current_date();
        await this.write(datelocator.textbox_date, date);
        await this.clickElement(datelocator.panel_heading);
    }

   async validateEnteredDate(){
        let entered_date=await this.getcssValue(datelocator.textbox_date);
        console.log("entered date="+entered_date);
        return entered_date;
    }

    async findDateStatus(date){
        // await this.find_element(datelocator.select_date(date));
        let status=await this.validateEnabled(select_date(date));
        return status;
    }

    async validateDay(date){
        let attr=await this.find_element(datelocator.select_date(date));
        let status=await attr.getAttribute("class");
        if(status=="disabled disabled-date day")
        {
            return true;
        }
        else{
            return false;
        }
        
    }

    async validateDateValue(){
        let element=await this.read(datelocator.textbox_date);
        return element;
    }

    async clearDate(){
        await this.clickElement(datelocator.btn_clear)
    }

}
module.exports = Datepicker;