let Page = require("../common/base_page");
let downloadlocator = require("../locator/downloadlocator.js");
const { Builder, By, Key, until, WebElement } = require('selenium-webdriver');
let assert = require("chai").assert;

class DownLoad extends Page{
    constructor(driver) {
        super();
        this.driver = driver;
    }

    async clickForDownLoad(){
        await this.clickElement(downloadlocator.btn_download);
    }
    // async WaitForElementVisible(locator) {
    //     let element = await this.find_element(locator);
    //     await this.driver.wait(until.elementIsVisible(element), 2000);
    
    //   }

    async waitForProgress(){
        let progress_ele=await this.find_element(downloadlocator.progress_circle);
        await this.driver.wait(until.elementTextContains(progress_ele,"100%"));
    }

    async validateCompletion(){
        let progress_txt=await this.read(downloadlocator.progress_circle);
        console.log(progress_txt);
        return progress_txt;
    }

}
module.exports=DownLoad;