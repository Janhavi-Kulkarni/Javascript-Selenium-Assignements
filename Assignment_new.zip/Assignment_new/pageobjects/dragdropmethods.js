let Page = require("../common/base_page");
let dragdroplocator = require("../locator/dragdroplocator.js");
const { Builder, By, Key, until, WebElement,Actions} = require('selenium-webdriver');
let assert = require("chai").assert;
let List = require("collections/list");

class DragDropComponent extends Page{
    constructor(driver) {
        super();
        this.driver = driver;
    }

    async dragDrop(draggable_name){
        let draggable=await this.find_element(dragdroplocator.dragable_components(draggable_name));
        let droppable=await this.find_element(dragdroplocator.dropzone);
       
        await this.driver
            .actions()
            .dragAndDrop(draggable, droppable)
            .perform();

            await this.wait(1000);
    }

    async verifyDropResult(){
        let drop_result=await this.read(dragdroplocator.droped_item_list);
        console.log(drop_result);
        return drop_result;
        
    }


}
module.exports=DragDropComponent;