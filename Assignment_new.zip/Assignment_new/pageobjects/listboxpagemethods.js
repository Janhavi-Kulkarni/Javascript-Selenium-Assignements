let Page = require("../common/base_page");
let listboxlocator = require("../locator/listboxlocator.js");
const { Builder, By, Key, until, WebElement,Actions } = require('selenium-webdriver');
let assert = require("chai").assert;
let List = require("collections/list");

class ListBox extends Page{
    constructor(driver) {
        super();
        this.driver = driver;
    }

    async selectSingleListBox(item){
        let ele=await this.find_element(listboxlocator.list_option(item));
        await this.driver.actions().click(ele).perform();
        
    }

    async selectListBoxes(item1,item2){
        let ele=await this.find_element(listboxlocator.list_option(item1));
        await this.driver.actions().click(ele).click(ele).perform();

        let ele1=await this.find_element(listboxlocator.list_option(item2));
        await this.driver.actions().click(ele1).click(ele1).perform();
    }

    async movetoTarget(){
        await this.clickElement(listboxlocator.btn_moveright);
    }
    async moveToSource(){
        await this.clickElement(listboxlocator.btn_moveleft);
    }
    async selectAllSource(){
        await this.clickElement(listboxlocator.select_all_left);
    }
    async selectAllTarget(){
        await this.clickElement(listboxlocator.select_all_right);
    }
}
module.exports=ListBox;