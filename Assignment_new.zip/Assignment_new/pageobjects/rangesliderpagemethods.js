let Page = require("../common/base_page");
let rangesliderlocator = require("../locator/rangesliderslocator.js");
const { Builder, By, Key, until, WebElement } = require('selenium-webdriver');
let assert = require("chai").assert;

class RangeSlider extends Page{
    constructor(driver) {
        super();
        this.driver = driver;
    }

    async setRangeValue(value){
        let output=await this.read(rangesliderlocator.rng_one_output);
        console.log(output);
        
    }
    async setSliderOne(){
        let element=await this.find_element(rangesliderlocator.rng_slider_one);
        let srcval=await element.getAttribute("value");
        console.log(srcval);
       await this.driver.executeScript("document.querySelector('.row.sliders:nth-child(2) div.col-md-6:nth-child(1) div.range:nth-child(2) > input:nth-child(1)').setAttribute('value', '60')");
        let targetval=await element.getAttribute("value");
       return targetval;

    }

    async setSliderTwo(){
        let element=await this.find_element(rangesliderlocator.rng_slider_two);
        let srcval=await element.getAttribute("value");
        console.log(srcval);
       await this.driver.executeScript("document.querySelector('.row.sliders:nth-child(2) div.col-md-6:nth-child(2) div.range:nth-child(2) > input:nth-child(1)').setAttribute('value', '60')");
        let targetval=await element.getAttribute("value");
       return targetval;

    }

    async setSliderThree(){
        let element=await this.find_element(rangesliderlocator.rng_slider_three);
        let srcval=await element.getAttribute("value");
        console.log(srcval);
       await this.driver.executeScript("document.querySelector('.row.sliders:nth-child(3) div.col-md-6:nth-child(1) div.range.range-success:nth-child(2) > input:nth-child(1)').setAttribute('value', '60')");
        let targetval=await element.getAttribute("value");
       return targetval;

    }

    async setSliderFour(){
        let element=await this.find_element(rangesliderlocator.rng_slider_four);
        let srcval=await element.getAttribute("value");
        console.log(srcval);
       await this.driver.executeScript("document.querySelector('.row.sliders:nth-child(3) div.col-md-6:nth-child(2) div.range.range-info:nth-child(2) > input:nth-child(1)').setAttribute('value', '60')");
        let targetval=await element.getAttribute("value");
       return targetval;

    }

    async setSliderFive(){
        let element=await this.find_element(rangesliderlocator.rng_slider_five);
        let srcval=await element.getAttribute("value");
        console.log(srcval);
       await this.driver.executeScript("document.querySelector('.row.sliders:nth-child(4) div.col-md-6:nth-child(1) div.range.range-warning:nth-child(2) > input:nth-child(1)').setAttribute('value', '60')");
        let targetval=await element.getAttribute("value");
       return targetval;

    }

    async setSliderSix(){
        let element=await this.find_element(rangesliderlocator.rng_slider_six);
        let srcval=await element.getAttribute("value");
       await this.driver.executeScript("document.querySelector('.row.sliders:nth-child(4) div.col-md-6:nth-child(2) div.range.range-danger:nth-child(2) > input:nth-child(1)').setAttribute('value', '60')");
        let targetval=await element.getAttribute("value");
       return targetval;

    }
}
module.exports=RangeSlider;