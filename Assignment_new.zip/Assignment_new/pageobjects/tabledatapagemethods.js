let Page = require("../common/base_page");
let tabledatalocator = require("../locator/tabledatalocator.js");
const { Builder, By, Key, until, WebElement } = require('selenium-webdriver');
let assert = require("chai").assert;
let List = require("collections/list");

class TableData extends Page{
    constructor(driver) {
        super();
        this.driver = driver;
    }

    async enterFilterCriteria(value){
        
        await this.write(tabledatalocator.tsk_txt_filter, value);
        
        
    }

    async clearFilterCriteria(){
        await this.clearText(tabledatalocator.tsk_txt_filter);
    }

    async validateResultAssignee(){
        let search_result=await this.read(tabledatalocator.tsk_search_result_assignee);
        return search_result;
    }

    async validateResultStatus(){
        let search_result=await this.read(tabledatalocator.tsk_search_result_status);
        return search_result;
    }

    async validateResultCount(value){
        List=await this.find_elements(tabledatalocator.tsk_filtered_data(value));
       console.log (List.length);
       return List.length;
    }

    async usrtable_enbleFilter(){
            await this.clickElement(tabledatalocator.usr_btn_filter);
    }

    async usrtable_filter_usrname(value){
        if(!(await this.validateEnabled(tabledatalocator.usr_txt_username))){
            await this.usrtable_enbleFilter();
            await this.write(tabledatalocator.usr_txt_username, value);
        }

    }

    async usrtable_validateResult(){
        let search_result=await this.read(tabledatalocator.usr_search_result_usrname);
        return search_result;
    }

}
module.exports=TableData;