let base_page = require("../common/base_page.js");
let alert_page = require("../pageobjects/alertpagemethods");
let alertpage, basepage;
let assert = require("chai").assert;

describe("Alert Operations", function () {
    this.timeout(50000); 

    describe("Validate Alerts", function () {
        beforeEach(async function () {

            basepage = new base_page();
            await basepage.init();
            alertpage = new alert_page(basepage.driver);
            
        });

        afterEach(async function () {
            await basepage.close();
            await basepage.quit();
        });

        it("Validate the alert box test and click on OK ", async function (){
            await basepage.navigateToUrl("https://www.seleniumeasy.com/test/javascript-alert-box-demo.html");
            await alertpage.validateAlert();
        });

        it("Accept confirmation and validate", async function (){
            await basepage.navigateToUrl("https://www.seleniumeasy.com/test/javascript-alert-box-demo.html");
            await alertpage.acceptConfirmtion();
            let txt_to_validate=await alertpage.validateConfirmationResult();
            assert.equal(txt_to_validate,"You pressed OK!")
        });

        it("Cancel confirmation and validate", async function (){
            await basepage.navigateToUrl("https://www.seleniumeasy.com/test/javascript-alert-box-demo.html");
            await alertpage.cancelConfirmtion();
            let txt_to_validate=await alertpage.validateConfirmationResult();
            assert.equal(txt_to_validate,"You pressed Cancel!")
        });

        it("Send text to prompt,accept and validate", async function (){
            let text="test data"
            await basepage.navigateToUrl("https://www.seleniumeasy.com/test/javascript-alert-box-demo.html");
            await alertpage.promptAccept(text);
            let txt_to_validate=await alertpage.validatePromptResult();
            assert.equal(txt_to_validate,`You have entered '${text}' !`)
        });
        

    });
});
