let base_page = require("../common/base_page.js");
let datepicker_page = require("../pageobjects/datepickerpagemethods");
let datepickerpage, basepage;
let assert = require("chai").assert;

describe("DatePicker Operations", function () {
    this.timeout(50000); 

    describe("Select and Validate Date", function () {
        beforeEach(async function () {

            basepage = new base_page();
            await basepage.init();
            datepickerpage = new datepicker_page(basepage.driver);
            
        });

        afterEach(async function () {
            await basepage.close();
            await basepage.quit();
        });

        it("Select Date as today's date", async function () {
           
            await basepage.navigateToUrl("https://www.seleniumeasy.com/test/bootstrap-date-picker-demo.html");
            await datepickerpage.click_on_datepicker();
            await datepickerpage.selectDate_today();
        });

        it("Select any date dd/mm/yyyy", async function () {
           
            await basepage.navigateToUrl("https://www.seleniumeasy.com/test/bootstrap-date-picker-demo.html");
            await datepickerpage.click_on_datepicker(); 
            await datepickerpage.selectDate_write("8/3/2020");       
           
        });

        it("Validate future date is disabled", async function (){
            await basepage.navigateToUrl("https://www.seleniumeasy.com/test/bootstrap-date-picker-demo.html");
            await datepickerpage.click_on_datepicker();         
            let result=await datepickerpage.validateFutureDate("20");  
            assert.equal(result,true) 
        
        });

        it("Validate Sunday is disabled", async function (){
            await basepage.navigateToUrl("https://www.seleniumeasy.com/test/bootstrap-date-picker-demo.html");
            await datepickerpage.click_on_datepicker();         
            let result=await datepickerpage.validateDay("10");  
            assert.equal(result,true) 
        
        });
    });
});
