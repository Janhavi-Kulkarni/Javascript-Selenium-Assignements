let base_page = require("../common/base_page.js");
let download_page = require("../pageobjects/downloadpagemethods");
let downloadpage, basepage;
let assert = require("chai").assert;

describe("Download Operations", function () {
    this.timeout(50000); 

    describe("Download and Validate", function () {
        beforeEach(async function () {

            basepage = new base_page();
            await basepage.init();
            downloadpage = new download_page(basepage.driver);
            
        });

        afterEach(async function () {
            await basepage.close();
            await basepage.quit();
        });

        it("Download the content and validate progress", async function (){
            await basepage.navigateToUrl("https://www.seleniumeasy.com/test/bootstrap-download-progress-demo.html");
            await downloadpage.clickForDownLoad();
            await downloadpage.waitForProgress();
            let validation_txt=await downloadpage.validateCompletion();
            assert.equal(validation_txt,"100%");

        });
        
        
    });
});
