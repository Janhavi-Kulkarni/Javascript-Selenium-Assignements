let base_page = require("../common/base_page.js");
let dragdrop_page = require("../pageobjects/dragdropmethods");
let dragdroppage, basepage;
let assert = require("chai").assert;

describe("Drag and Drop Operations", function () {
    this.timeout(50000); 

    describe("Drag and Drop elements", function () {
        beforeEach(async function () {

            basepage = new base_page();
            await basepage.init();
            dragdroppage = new dragdrop_page(basepage.driver);
            
        });

        afterEach(async function () {
            await basepage.close();
            await basepage.quit();
        });

        it("Drag and drop one draggable component", async function (){
            await basepage.navigateToUrl("https://www.seleniumeasy.com/test/drag-and-drop-demo.html");
            await dragdroppage.dragDrop("Draggable 1");
        });

        it("Drag and drop two draggable component", async function (){
            await basepage.navigateToUrl("https://www.seleniumeasy.com/test/drag-and-drop-demo.html");
            await dragdroppage.dragDrop("Draggable 1");
            await dragdroppage.dragDrop("Draggable 2");
        });
        

    });
});
