let base_page = require("../common/base_page.js");
let listbox_page = require("../pageobjects/listboxpagemethods");
let listboxpage, basepage;
let assert = require("chai").assert;

describe("ListBox Operations", function () {
    this.timeout(50000); 

    describe("Lisbox Demo", function () {
        beforeEach(async function () {

            basepage = new base_page();
            await basepage.init();
            listboxpage = new listbox_page(basepage.driver);
            
        });

        afterEach(async function () {
            await basepage.close();
            await basepage.quit();
        });

        it("Select single item, move to right and vice versa", async function (){
            await basepage.navigateToUrl("https://www.seleniumeasy.com/test/bootstrap-dual-list-box-demo.html");
            await listboxpage.selectSingleListBox("bootstrap-duallist");
            await listboxpage.movetoTarget();
            await listboxpage.selectSingleListBox("bootstrap-duallist");
            await listboxpage.moveToSource();

        });

        it("Select multiple item, move to right and vice versa", async function (){
            await basepage.navigateToUrl("https://www.seleniumeasy.com/test/bootstrap-dual-list-box-demo.html");
            await listboxpage.selectListBoxes("bootstrap-duallist","Dapibus ac facilisis in");
            await listboxpage.movetoTarget();
            await listboxpage.selectListBoxes("bootstrap-duallist","Dapibus ac facilisis in");
            await listboxpage.moveToSource();

        });

        it("Select all item, move to right and vice versa", async function (){
            await basepage.navigateToUrl("https://www.seleniumeasy.com/test/bootstrap-dual-list-box-demo.html");
            await listboxpage.selectAllSource();
            await listboxpage.movetoTarget();
            await listboxpage.selectAllTarget();
            await listboxpage.moveToSource();

        });
        
    });
});
