let base_page = require("../common/base_page.js");
let rangeslider_page = require("../pageobjects/rangesliderpagemethods");
let rangesliderpage, basepage;
let assert = require("chai").assert;

describe("Rangeslider demo", function () {
    this.timeout(50000); 

    describe("Validate Rangeslider", function () {
        beforeEach(async function () {

            basepage = new base_page();
            await basepage.init();
            rangesliderpage = new rangeslider_page(basepage.driver);
            
        });

        afterEach(async function () {
            await basepage.close();
            await basepage.quit();
        });

        it("Set value of first range slider to 60", async function (){
            await basepage.navigateToUrl("https://www.seleniumeasy.com/test/drag-drop-range-sliders-demo.html");
            let val_to_validate=await rangesliderpage.setSliderOne();
            assert.equal(val_to_validate,"60");
        });

        it("Set value of second range slider to 60", async function (){
            await basepage.navigateToUrl("https://www.seleniumeasy.com/test/drag-drop-range-sliders-demo.html");
            let val_to_validate=await rangesliderpage.setSliderTwo();
            assert.equal(val_to_validate,"60");
        });

        it("Set value of third range slider to 60", async function (){
            await basepage.navigateToUrl("https://www.seleniumeasy.com/test/drag-drop-range-sliders-demo.html");
            let val_to_validate=await rangesliderpage.setSliderThree();
            assert.equal(val_to_validate,"60");
        });

        it("Set value of fourth range slider to 60", async function (){
            await basepage.navigateToUrl("https://www.seleniumeasy.com/test/drag-drop-range-sliders-demo.html");
            let val_to_validate=await rangesliderpage.setSliderFour();
            assert.equal(val_to_validate,"60");
        });

        it("Set value of fifth range slider to 60", async function (){
            await basepage.navigateToUrl("https://www.seleniumeasy.com/test/drag-drop-range-sliders-demo.html");
            let val_to_validate=await rangesliderpage.setSliderFive();
            assert.equal(val_to_validate,"60");
        });
        it("Set value of sixth range slider to 60", async function (){
            await basepage.navigateToUrl("https://www.seleniumeasy.com/test/drag-drop-range-sliders-demo.html");
            let val_to_validate=await rangesliderpage.setSliderSix();
            assert.equal(val_to_validate,"60");
        });

        
        
        
    });
});
