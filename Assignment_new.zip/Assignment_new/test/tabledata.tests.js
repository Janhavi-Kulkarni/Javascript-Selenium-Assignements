let base_page = require("../common/base_page.js");
let tabledata_page = require("../pageobjects/tabledatapagemethods");
let tabledatapage, basepage;
let assert = require("chai").assert;

describe("Tabledata Operations", function () {
    this.timeout(50000); 

    describe("Apply and Validate Filters", function () {
        beforeEach(async function () {

            basepage = new base_page();
            await basepage.init();
            tabledatapage = new tabledata_page(basepage.driver);
            
        });

        afterEach(async function () {
            await basepage.close();
            await basepage.quit();
        });

        it("Apply filter for assignee and validate result", async function (){
            await basepage.navigateToUrl("https://www.seleniumeasy.com/test/table-search-filter-demo.html");
            await tabledatapage.enterFilterCriteria("John Smith");
            let validate_txt=await tabledatapage.validateResultAssignee();
            assert.equal(validate_txt,"John Smith");
            await tabledatapage.clearFilterCriteria();
        });
        
        it("Apply filter for status and validate count", async function (){
            await basepage.navigateToUrl("https://www.seleniumeasy.com/test/table-search-filter-demo.html");
            await tabledatapage.enterFilterCriteria("in progress");
            let validate_cnt=await tabledatapage.validateResultCount("in progress");
            assert.isAtLeast(validate_cnt,1);
    
        });

        it("Apply filter for username and validate result", async function (){
            await basepage.navigateToUrl("https://www.seleniumeasy.com/test/table-search-filter-demo.html");
            
            await tabledatapage.usrtable_filter_usrname("larrypt");
            let validate_txt=await tabledatapage.usrtable_validateResult();
            assert.equal(validate_txt,"larrypt");
           
        });
    });
});
